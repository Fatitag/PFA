
public class Adherent {

}
